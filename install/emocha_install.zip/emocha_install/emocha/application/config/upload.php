<?php defined('SYSPATH') OR die('No direct access allowed.');

return array('directory' => DOCROOT.'sdcard/upload',
			'create_directories' => FALSE,
			'remove_spaces' => TRUE
			);