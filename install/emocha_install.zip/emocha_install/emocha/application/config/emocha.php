<?php defined('SYSPATH') OR die('No direct access allowed.');
// EDIT some basic info
return array(
	'version_name' => 'Emocha Demo',
	'admin_alerts_to' => 'your email address',
	
					
);