<?php defined('SYSPATH') OR die('No direct access allowed.');
return array(
	'authentication' => 'usr_password'
);