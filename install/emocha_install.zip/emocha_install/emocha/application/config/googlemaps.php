<?php defined('SYSPATH') OR die('No direct access allowed.');

// EDIT your googlemaps key
return array(
	
	'key' => '',
				
);