<?php defined('SYSPATH') OR die('No direct access allowed.');

return array
(
	'driver' => 'ORM',
	'hash_method' => 'sha1',
	// EDIT: modify salt pattern for web user password hashing
	'salt_pattern' => '2, 3, 5, 9, 11, 14, 19, 21, 25, 30',
	'lifetime' => 1209600,
	'session_key' => 'auth_user',
	'users' => array
	(
	),
);
