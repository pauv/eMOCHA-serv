<?php defined('SYSPATH') OR die('No direct access allowed.');

// EDIT: 15 char key
return array
(
	'key' => 'qwerty123456789'
);