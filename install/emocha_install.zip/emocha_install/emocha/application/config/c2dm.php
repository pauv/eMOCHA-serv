<?php defined('SYSPATH') OR die('No direct access allowed.');

return array(
	
	// EDIT
	'user' => 'accountname@gmail.com',
	'password' => 'pass'
				
);