<?php defined('SYSPATH') or die('No direct script access.');

return array ( 
	
	'invalid_application_type' => 'The current application type is invalid. Check your DB entries and eMOCHA documentation regarding platform config values',
	'application_type_missing' => 'Application type is missing. Check your DB entries and eMOCHA documentation regarding platform config values'
);
