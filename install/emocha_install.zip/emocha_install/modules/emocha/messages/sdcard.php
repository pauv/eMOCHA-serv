<?php defined('SYSPATH') or die('No direct script access.');

return array ( 
	
	'userfile' => Array
	( 
		'upload::valid'=> 'Invalid upload data',
		'upload::not_empty' => 'Select a file for upload',
		'upload::type' => 'Invalid file type',
		'upload::size' => 'File too big',
	),
	
	'thumbnail' => Array
	( 
		'upload::valid'=> 'Invalid upload data',
		'upload::not_empty' => 'Select a file for upload',
		'upload::type' => 'Invalid file type',
		'upload::size' => 'File too big',
	),
	
	'ftp_file' => 'Ftp file could not be copied',
	'upload_file' => 'Uploaded file could not be saved',

);
