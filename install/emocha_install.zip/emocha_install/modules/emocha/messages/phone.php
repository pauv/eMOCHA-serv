<?php defined('SYSPATH') or die('No direct script access.');

return array ( 
	
	'activate' => Array
	( 
		
		'phone_activation_sent' => 'Phone activation sent. The administrator will contact you.',
		'phone_auto_validate' => 'Phone activated.',
		'phone_activation_bad_imei' => 'Server says invalid or missing IMEI code!',
		'phone_activation_exists' => 'Server says this phone already requested a password. You should be contacted by a team member soon.',
	),
	'enter_password' => 'Enter a password',
	
);