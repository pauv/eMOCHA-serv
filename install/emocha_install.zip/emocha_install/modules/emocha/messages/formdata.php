<?php defined('SYSPATH') or die('No direct script access.');

return array ( 
	

	'referral_id_not_found' => 'Referral id could not be found, please check id',
	'referral_not_logged' => 'Referral could not be logged, please try again',

);
