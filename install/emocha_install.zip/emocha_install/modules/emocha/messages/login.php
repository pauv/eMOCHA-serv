<?php defined('SYSPATH') or die('No direct script access.');

return array ( 
	
	'username' => Array
	( 
		'default'=> 'Invalid username or password',
		'unconfirmed'=> 'Your account must first be activated and confirmed by the administrator'
		
	),
	'password' => Array
	( 
		'default'=> 'Invalid username or password'
	),
	

);
