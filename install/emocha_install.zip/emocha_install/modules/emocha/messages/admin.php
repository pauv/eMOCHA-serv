<?php defined('SYSPATH') or die('No direct script access.');

return array ( 
	
	'invalid_time_zone' => 'Time zone you entered does not exist. Please take a valid one from here: <a href="http://www.php.net/manual/en/timezones.php" target="_blank">http://www.php.net/manual/en/timezones.php</a>'

);
