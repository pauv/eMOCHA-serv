<?php defined('SYSPATH') OR die('No direct access allowed.');

return array(
	

	'user' => '',
	'password' => '',
	'api_id' => '',
				
);