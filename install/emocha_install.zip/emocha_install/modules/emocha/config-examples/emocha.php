<?php defined('SYSPATH') OR die('No direct access allowed.');
return array(
	'version_name' => 'Site label',
	'admin_alerts_to' => 'email_address'
					
);