<?php defined('SYSPATH') OR die('No direct access allowed.');

return array
(
	'key' => 'db-encryption-key'
);