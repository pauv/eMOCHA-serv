<?php if (count($errors)) { ?>
<div class="st_ERR">
	<?php foreach($errors as $error){
		echo $error.'<br />';
	} ?>
</div>
<?php } ?>


