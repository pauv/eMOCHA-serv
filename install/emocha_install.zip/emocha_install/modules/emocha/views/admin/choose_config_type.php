<table class="list">
	<tr>
		<td><a href="<?php echo Url::site('admin/configs/platform') ?>">Platform config</a></td>
		<td><a href="<?php echo Url::site('admin/configs/server') ?>">Server config</a></td>
		<td><a href="<?php echo Url::site('admin/configs/android') ?>">Android config</a></td>
	</tr>
</table>
