	<li id="nav_new_users"><a href="<?php echo Url::site('admin/new_users') ?>">new users</a></li>
	<li id="nav_forms"><a href="<?php echo Url::site('admin/forms') ?>">forms</a></li>
	<li id="nav_configs"><a href="<?php echo Url::site('admin/configs') ?>">configs</a></li>
	<li id="nav_phones"><a href="<?php echo Url::site('admin/phones') ?>">phones</a></li>
	<li id="nav_alarms"><a href="<?php echo Url::site('admin/alarms') ?>">alarms</a></li>
	
