	<li id="nav_library"><a href="<?php echo Url::site('edu/library') ?>">library</a></li>
	<li id="nav_courses"><a href="<?php echo Url::site('edu/courses') ?>">courses</a></li>
	<li id="nav_lectures"><a href="<?php echo Url::site('edu/lectures') ?>">lectures</a></li>
