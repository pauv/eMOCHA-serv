	<li id="nav_details"><a href="<?php echo Url::site('account/details') ?>">details</a></li>
	<li id="nav_edit_details"><a href="<?php echo Url::site('account/edit_details') ?>">edit details</a></li>
	<li id="nav_change_password"><a href="<?php echo Url::site('account/change_password') ?>">change password</a></li>
	