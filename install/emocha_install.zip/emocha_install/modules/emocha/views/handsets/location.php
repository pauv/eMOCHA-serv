<?php echo $gmaps_js; ?>

<div id="inner_content">
<div id="map_canvas"></div>
</div>
