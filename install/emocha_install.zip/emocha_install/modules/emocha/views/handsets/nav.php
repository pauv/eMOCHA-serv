	<li id="nav_phones"><a href="<?php echo Url::site('handsets/phones') ?>">phones</a></li>
	<li id="nav_location"><a href="<?php echo Url::site('handsets/location') ?>">location</a></li>
