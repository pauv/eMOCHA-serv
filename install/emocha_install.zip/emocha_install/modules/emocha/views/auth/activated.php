<div id="inner_content">
<b>Account Activated</b>



<p>Once the eMOCHA adminstrator has confirmed your account, you'll receive a notification and will be able to log in.</p>
</div>