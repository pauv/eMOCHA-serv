<div id="inner_content">
<b>Your password has been reset</b>



<p>You can now <?php echo Html::anchor('auth/login', 'login with your new password'); ?></p>
</div>