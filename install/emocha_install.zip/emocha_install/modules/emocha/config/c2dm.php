<?php defined('SYSPATH') OR die('No direct access allowed.');

return array(
	

	'user' => 'emocha.dev@gmail.com',
	'password' => 'AiTu2Foh/S'
				
);