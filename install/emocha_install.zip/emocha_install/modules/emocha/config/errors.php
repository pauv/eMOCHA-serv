<?php defined('SYSPATH') OR die('No direct access allowed.');
return array(
	'config_missing' => 'Config value is missing. Server config must be reviewed',
	'wrong_auth_type' => 'Invalid platform authentication type. Server config must be reviewed',
	'wrong_app_type' => 'Invalid platform application type. Server config must be reviewed',
	'unknown_user' => 'Unknown user'

);
