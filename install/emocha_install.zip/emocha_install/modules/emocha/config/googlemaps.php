<?php defined('SYSPATH') OR die('No direct access allowed.');

return array(
	
	'key' => 'ABQIAAAA40rzOgxYas4wHhxR6cy9aBT2yXp_ZAY8_ufC3CFXhHIE1NvwkxSiS00OX9MtroSpgPfIIPCrwlcCZg',
				
);