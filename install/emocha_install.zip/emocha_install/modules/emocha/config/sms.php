<?php defined('SYSPATH') OR die('No direct access allowed.');

return array(
	

	'user' => 'JHUCCGHE',
	'password' => 'StRAe99geiya438',
	'api_id' => '3264452',
				
);