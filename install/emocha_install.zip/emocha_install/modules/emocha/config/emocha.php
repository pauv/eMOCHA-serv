<?php defined('SYSPATH') OR die('No direct access allowed.');
return array(
	'version_name' => 'Dev site',
	'admin_alerts_to' => 'george@ggraham.net',
	
					
);