<?php defined('SYSPATH') or die('No direct script access.');
/**
 * Stats helper
 *
 * @package    eMOCHA
 * @author     George Graham
 * @copyright  2010-2012 George Graham - gwgrahamx@gmail.com
 * @license    GNU General Public License - http://www.gnu.org/licenses/gpl.html
 */  
class Stats extends Emocha_Stats
    {   
    
    }