<?php defined('SYSPATH') or die('No direct script access.');
/**
 * Api Controller
 *
 * @package    eMOCHA
 * @author     George Graham
 * @copyright  2010-2012 George Graham - gwgrahamx@gmail.com
 * @license    GNU General Public License - http://www.gnu.org/licenses/gpl.html
 */  
class Controller_Api extends Emocha_Controller_Api {

}