<?php defined('SYSPATH') or die('No direct script access.');
/**
 * Phone Alert Model
 *
 * @package    eMOCHA
 * @author     George Graham
 * @copyright  2010-2012 George Graham - gwgrahamx@gmail.com
 * @license    GNU General Public License - http://www.gnu.org/licenses/gpl.html
 */ 
class Model_Phone_Alert extends ORM {

}